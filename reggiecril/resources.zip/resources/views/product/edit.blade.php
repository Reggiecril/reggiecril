@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Edit product </div>
                <div class="panel-body">

                    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <strong>create failed</strong> enter right charester<br><br>
                            {!! implode('<br>', $errors->all()) !!}
                        </div>
                    @endif

                    <form action="{{ url('/product/'.$product->id) }}" method="POST">
                        {{method_field('PUT')}}
                        {!! csrf_field() !!}
                        <input type="text" name="name" class="form-control"  placeholder="Name" value="{{$product->name}}">
                        <br>
                        <input type="text" name="type" class="form-control"  placeholder="Type" value="{{$product->type}}">
                        <br>
                        <input type="text" name="price" class="form-control"  placeholder="Price" value="{{$product->price}}">
                        <br>
                        <input type="text" name="image" class="form-control"  placeholder="Image" value="{{$product->image}}">
                        <br>
                        <button class="btn btn-lg btn-info">Edit</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection