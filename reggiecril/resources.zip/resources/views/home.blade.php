@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <ul style="text-align:center;list-style: none;">
                    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            {!! implode('<br>', $errors->all()) !!}
                        </div>
                    @endif
                    <a href="{{ url('/product/create') }}" class="btn btn-lg btn-primary">New</a>
                    @foreach ($products as $product)
                    <li  style="margin: 20px 20px;border:1px solid #eee">
                        <div style="display: inline-block;text-align:center;width: 200px;">
                            <a href="{{ url('/product/'.$product->id) }}">
                                <h4>{{ $product->name }}</h4>
                            </a>
                        </div>
                        <div style="display: inline-block;text-align:center;width: 100px;">
                            <p>{{ $product->type }}</p>
                        </div>
                        <div style="display: inline-block;text-align:center;width: 100px;">
                            <p>{{ $product->price }}</p>
                        </div>
                        <div style="display: inline-block;text-align:center;width: 150px;">
                            <img src="{{ '../assets/images/'.$product->image }}" width="100px" height="150px">
                        </div>
                        <div style="display: inline-block;float:right;text-align:center;width: 15%;">
                            <a href="{{ url('/product/'.$product->id.'/edit') }}" class="btn btn-success">Edit</a>
                            <form action="{{ url('/product/'.$product->id) }}" method="POST" style="display: inline;">
                                {{ method_field('DELETE') }}
                                {{ csrf_field() }}
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection
