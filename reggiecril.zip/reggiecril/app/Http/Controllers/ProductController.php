<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
class ProductController extends Controller
{
	public function create()
	{
	    return view('product/create');
	}
	public function store(Request $request)
	{

	    $product = new Product;
	    $product->name = $request->get('name');
	    $product->type = $request->get('type');
	    $product->price = $request->get('price');
	    $product->image = $request->get('image');

	    if ($product->save()) {
	        return redirect('product');
	    } else {
	        return redirect()->back()->withInput()->withErrors('Save failed!');
	    }
	}
	public function destroy($id)
	{
	    Product::find($id)->delete();
	    return redirect()->back()->withInput()->withErrors('Delete Successed!');
	}
	public function edit($id)
	{
	    $product = Product::find($id);
	    return view('product/edit',compact('product'));
	}
	public function update(Request $request, $id)
	{
		$product = Product::find($id);
	    $product->name = $request->input('name');
	    $product->type = $request->input('type');
	    $product->price = $request->input('price');
	    $product->image = $request->input('image');
		$product->update();
		return redirect('/product');
	}
	public function index()
    {
    	return view('home')->withProducts(\App\Product::all());
    }
}