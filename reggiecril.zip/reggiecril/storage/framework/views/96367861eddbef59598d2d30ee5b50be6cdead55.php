<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Learn Laravel 5</title>

    <link href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <script src="//cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
    <script src="//cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
            .top-right {
                position: relative;
                height: 50px;
                line-height: 50px;
                background-color: #eee;
            }



            .links > a {

                color: #636b6f;
                padding: 0 25px;
                font-size: 16px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }
</style>
</head>
<body>
    <div class="top-right links">
        <a href="<?php echo e(url('/')); ?>">Home</a>
    </div>
    <div id="content">
        <ul style="text-align:center;list-style: none;border: 10px dotted;border-radius: 15px;">
            <div style="display: inline-block;text-align:center;width: 30%;font-size: 20px;">
                    <p>Name</p>
            </div>
            <div style="display: inline-block;text-align:center;width: 15%;font-size: 20px;">
                    <p>Type</p>
            </div>
            <div style="display: inline-block;text-align:center;width: 15%;font-size: 20px;">
                    <p>Price</p>
            </div>
            <div style="display: inline-block;text-align:center;width: 20%;font-size: 20px;">
                    <p>Image</p>
            </div>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li  style="margin: 50px 0;">
                <div style="display: inline-block;text-align:center;width: 30%;">
                    <a href="<?php echo e(url('product/'.$product->id)); ?>">
                        <h4><?php echo e($product->name); ?></h4>
                    </a>
                </div>
                <div style="display: inline-block;text-align:center;width: 15%;">
                    <p><?php echo e($product->type); ?></p>
                </div>
                <div style="display: inline-block;text-align:center;width: 15%;">
                    <p><?php echo e($product->price); ?></p>
                </div>
                <div style="display: inline-block;text-align:center;width: 20%;">
                    <img src="<?php echo e('../assets/images/'.$product->image); ?>" width="200px" height="250px">
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

</body>
</html>


