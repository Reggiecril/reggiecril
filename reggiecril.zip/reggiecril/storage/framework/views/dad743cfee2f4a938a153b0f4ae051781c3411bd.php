<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <ul style="text-align:center;list-style: none;">
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php echo implode('<br>', $errors->all()); ?>

                        </div>
                    <?php endif; ?>
                    <a href="<?php echo e(url('/product/create')); ?>" class="btn btn-lg btn-primary">New</a>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li  style="margin: 20px 20px;border:1px solid #eee">
                        <div style="display: inline-block;text-align:center;width: 200px;">
                            <a href="<?php echo e(url('/product/'.$product->id)); ?>">
                                <h4><?php echo e($product->name); ?></h4>
                            </a>
                        </div>
                        <div style="display: inline-block;text-align:center;width: 100px;">
                            <p><?php echo e($product->type); ?></p>
                        </div>
                        <div style="display: inline-block;text-align:center;width: 100px;">
                            <p><?php echo e($product->price); ?></p>
                        </div>
                        <div style="display: inline-block;text-align:center;width: 150px;">
                            <img src="<?php echo e('../assets/images/'.$product->image); ?>" width="100px" height="150px">
                        </div>
                        <div style="display: inline-block;float:right;text-align:center;width: 15%;">
                            <a href="<?php echo e(url('/product/'.$product->id.'/edit')); ?>" class="btn btn-success">Edit</a>
                            <form action="<?php echo e(url('/product/'.$product->id)); ?>" method="POST" style="display: inline;">
                                <?php echo e(method_field('DELETE')); ?>

                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>