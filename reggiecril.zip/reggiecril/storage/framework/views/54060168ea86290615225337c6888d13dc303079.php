<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="Xie Yuncheng">
	<title>Reggie's Portfolio</title>
	<link href="https://fonts.googleapis.com/css?family=Playball" rel="stylesheet">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="reggiecril/resources/assets/style.css">
	<script type="text/javascript" src="reggiecril/resources/assets/js/jquery-3.3.1.js"></script>
	 <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="reggiecril/resources/assets/js/jquery.flexslider-min.js"></script>
</head>
<body>
		<div class="header">
			<div class="header-background"></div>
			<div class="header-content">
				<div class="header-topbar">
					<div class="header-icon">
						<h1>Reggiecril</h1>
					</div>
					<div style="display: inline-block;margin: 40px"></div>
					<div class="header-navigation ">
						<div class="nav">
							<ul class="nav_table">
								<li class="nav_table_cell">
									<a class="nav_table_cell_link"  href="<?php echo e(url('/')); ?>">
										<span></span> Home
									</a>
								</li>
								<li class="nav_table_cell">
									<a class="nav_table_cell_link" href="https://github.com/Reggiecril">
										<span></span> Github
									</a>
								</li>
								<li class="nav_table_cell">
									<a class="nav_table_cell_link" href="<?php echo e(url('/project')); ?>">
										<span></span> Projects
									</a>
								</li>
								<li class="nav_table_cell">
									<a class="nav_table_cell_link" href="https://www.linkedin.com/in/xie-yuncheng-038a16158">
										<span></span> Linkedin
									</a>
								</li>
								<li class="nav_table_cell">
									<a class="nav_table_cell_link" data-toggle="modal" data-target="#contact">
										<span></span> Contact Me
									</a>
								</li>
							</ul>
						</div>
					</div>
					<div class="header-search">
						<form action="" class="search-form">
			                <div class="form-group has-feedback">
			            		<label for="search" class="sr-only">Search</label>
			            		<input type="text" class="form-control" name="search" id="search" placeholder=" search">
			              		<span class="glyphicon glyphicon-search form-control-feedback"></span>
			            	</div>
			            </form>
					</div>
				</div>
				<div class="header-centerBar">
					<h1>Welcome To Xie's Portfolio</h1>
				</div>
				<div class="header-peopleIcon">
					<img src="reggiecril/resources/assets/Images/v2-2b86ee8ba2e3a8f2a6654832f96379f6_hd.jpg" width="200" height="200" style="border: 0 none; border-radius: 100px;">
				</div>
				<div class="header-description">
					<div class="header-description-content">
						<h1>Hi!</h1>
						<p>I am Xie Yuncheng.</p>
						<p> I am a <strong>Website Developer</strong>. I have multiple experience in website, have a good understanding in a range of <strong>HTML</strong>(Tag,DIV),<strong>JavaScript</strong>(jQuery,AngularJS,Ajax) and <strong>SQL</strong>(CRUD).</p>
					</div>
				</div>
			</div>
		</div>
		<div class="content">
			<div class="content-mainProject">
				<div class="flexslider">
					<ul class="slides">
						<li class="slides-a">
							<a href="cloudaping.com">
								<h1 style="position:absolute;text-align: center; font-size: 100px;top:37%;bottom:0;left:0;right:0;font-family: 'Playball', cursive;color:#D52341;">CloudaPing</h1>
								<div class="slides-cover">
								</div>
								<div class="slides-text">
									<h1 style="font-family: 'Playball', cursive;color:#D52341;">CloudaPing:</h1>
									<p style="color:#D52341;font-size: 20px;">This is a E-Commerce Website which focus on mobile,laptop,camera and some kind of electric product.</p>
								</div>
								<img src="reggiecril/resources/assets/Images/Screen-Shot-2014-01-02-at-4.27.12-AM.png" height="600" width="1400px"></a>
								
						</li>
						<li class="slides-a">
							<a href="reggiecril.com/web_dev.php">
								<h1 style="position:absolute;text-align: center; font-size: 100px;top:37%;bottom:0;left:0;right:0;font-family: 'Playball', cursive;color:#128954;">Whsii</h1>
								<div class="slides-cover"></div>
								<div class="slides-text">
									<h1 style="font-family: 'Playball', cursive;color:#128954;">Whsii</h1>
									<p style="color:#128954;font-size: 20px;">This is a E-Commerce Website which focus on Whisky.</p>
								</div>
								<img src="reggiecril/resources/assets/Images/_RHT5688_banner.jpg" height="600" width="1400px">
							</a>
						</li>
						<li>
							<a href="#">
								<h1 style="position:absolute;text-align: center; font-size: 100px;top:37%;bottom:0;left:0;right:0;font-family: 'Playball', cursive;color:#333;">Text Painter</h1>
								<div class="slides-cover"></div>
								<div class="slides-text">
									<h1 style="font-family: 'Playball', cursive;color:#333;">Text Painter:</h1>
									<p style="font-size: 20px;color:#333;">THis is a point board by typing coordinate. There are kinds of shape available.</p>
								</div>
								<img src="reggiecril/resources/assets/Images/380px-Olympic_flag.svg.png" height="600" width="1400px">
							</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="content-projectDescription">
			</div>
		</div>
		<script type="text/javascript">
			$(".slides-text").hide();
			$(".flexslider").mouseenter(function() {
			$(".slides-text").slideDown("normal");
			});
			$(".flexslider").mouseleave(function() {
			$(".slides-text").slideUp("normal");
			});
		</script>
		<div class="otherProject">
			<div class="otherProject-content">
				<div class="otherProject-content-first">
					<div class="imagechange-3d image-hover hover">
	                    <div class="imagechange-3d-inner">
	                        <div class="imgchange-1">
	                        	<h1 style="position: absolute;top:25%;left:20%;text-align: center;font-size: 60px;font-family: 'Playball', cursive;color:#D52341;">CloudaPing</h1>
	                        </div>
	                        <div class="imgchange-2">
	                            <img src="reggiecril/resources/assets/Images/Screen-Shot-2014-01-02-at-4.27.12-AM.png" height="250px" width="450px">
	                        </div>
	                    </div>
                	</div>
				</div>
				<div class="otherProject-content-second">
					<div class="imagechange-3d image-hover hover">
	                    <div class="imagechange-3d-inner">
	                        <div class="imgchange-1">
	                            <h1 style="position: absolute;top:25%;left:30%;text-align: center;font-size: 60px;font-family: 'Playball', cursive;color:#128954;">Whsii</h1>
	                        </div>
	                        <div class="imgchange-2">
	                            <img src="reggiecril/resources/assets/Images/_RHT5688_banner.jpg" height="250px" width="450px">
	                        </div>
	                    </div>
                	</div>
				</div>
				<div class="otherProject-content-third">
					<div class="imagechange-3d image-hover hover">
	                    <div class="imagechange-3d-inner">
	                         <div class="imgchange-1">
	                            <h1 style="position: absolute;top:25%;left:23%;text-align: center;font-size: 60px;font-family: 'Playball', cursive;color:#333;">Text Painter</h1>
	                        </div>
	                        <div class="imgchange-2">
	                            <img src="reggiecril/resources/assets/Images/380px-Olympic_flag.svg.png" height="250px" width="450px">
	                        </div>
	                    </div>
               		</div>
				</div>
			</div>
			<div class="otherProject-content">
				<div class="otherProject-content-first" style="margin-left: 200px;">
					<div class="imagechange-3d image-hover hover">
	                    <div class="imagechange-3d-inner">
	                        <div class="imgchange-1">
	                            <h1 style="position: absolute;top:25%;left:30%;text-align: center;font-size: 60px;color:#333;">Bronte</h1>
	                        </div>
	                        <div class="imgchange-2">
	                            <img src="reggiecril/resources/assets/Images/market.jpg" height="250px" width="450px">
	                        </div>
	                    </div>
                	</div>
				</div>				
				<div class="otherProject-content-third" >
					<div class="imagechange-3d image-hover hover">
	                    <div class="imagechange-3d-inner">
	                        <div class="imgchange-1">
	                            <h1 style="position: absolute;top:25%;left:15%;font-style:oblique;text-align: center;font-size: 60px;color:rgb(192,64,0);">Bug Tracker</h1>
	                        </div>
	                        <div class="imgchange-2" style="background-color: #fff;">
	                            <img src="reggiecril/resources/assets/Images/feedback-assistant-mac-icon-100596716-large.png" height="250px" width="450px">
	                        </div>
	                    </div>
               		</div>
				</div>
			</div>
			<div class="otherProject-content">
				<div class="otherProject-content-first">
					<div class="imagechange-3d image-hover hover">
	                    <div class="imagechange-3d-inner">
	                        <div class="imgchange-1">
	                            <h1 style="position: absolute;top:25%;left:25%;text-align: center;font-size: 60px;color:#333;">Fractal</h1>
	                        </div>
	                        <div class="imgchange-2">
	                            <img src="reggiecril/resources/assets/Images/Demm_2000_Mandelbrot_set.jpg" height="250px" width="450px">
	                        </div>
	                         <div style="opacity: 0.4;width: 450px;height: 250px;background-color: #fff;" ></div>
	                    </div>
                	</div>
				</div>
				<div class="otherProject-content-second">
					<div class="imagechange-3d image-hover hover">
	                    <div class="imagechange-3d-inner">
	                        <div class="imgchange-1">
	                            <h1 style="position: absolute;top:25%;left:30%;text-align: center;font-size: 60px;color:#D52341;">Polar</h1>
	                        </div>
	                        <div class="imgchange-2">
	                            <img src="reggiecril/resources/assets/Images/Polar.png" height="250px" width="450px">
	                        </div>
	                    </div>
                	</div>
				</div>
				<div class="otherProject-content-third">
					<div class="imagechange-3d image-hover hover">
	                    <div class="imagechange-3d-inner">
	                        <div class="imgchange-1">
	                            <h1 style="position: absolute;top:25%;left:30%;font-family: 'Playball', cursive;text-align: center;font-size: 60px;color:#D52341;">Whisky</h1>
	                        </div>
	                        <div class="imgchange-2">
	                            <img src="reggiecril/resources/assets/Images/best_whiskies_2018_-_whiskey_glass.jpg" height="250px" width="450px">
	                        </div>
	                    </div>
               		</div>
				</div>
			</div>
		</div>
		<div class="cv">
			<h1>What I Good At~~</h1>
			<div class="project-technology-first">
						<div class="project-technology-content col-lg-3">
								<img src="reggiecril/resources/assets/Images/200px-HTML5_logo_and_wordmark.svg.png" width="100" height="100" style="float: left;">
							<p><strong style="font-size: 24px;">T</strong>his is basic technology in webiste development. I have a good understanding in HTML, using DIV,Tag skillful.</p>
						</div>
						<div class="project-technology-content col-sm-3">
							
							<img src="reggiecril/resources/assets/Images/2000px-PHP-logo.svg.png" width="150" height="120" style="float: left;">
							<p><strong style="font-size: 24px;">T</strong>his the first language which I touched and learned. Most of my project is developed on it, its simple and dynamic are the best thing which I like. I have a deep study on PHP. OO Programming is used and I used Laravel for my PHP framework.</p>
						</div>
						<div class="project-technology-content">
							
							<img src="reggiecril/resources/assets/Images/Java.png" width="100" height="140" style="float: left;">
						
							<p><strong style="font-size: 24px;">I</strong> learned Java for one years ago and have a understanding in Java SE. There are few projects available. I like this language and i am very interesting in Java EE,so Java EE prepared that is my next stage.</p>
						</div>
					</div>
					<div class="project-technology-second">
							<div class="project-technology-content col-sm-3">
								<img src="reggiecril/resources/assets/Images/css-3.svg" width="120" height="120" style="float: left;">
								<p><strong style="font-size: 24px;">T</strong>his is necessary tecchnology in website design. I study it thre years ago, same as HTML. Bootstrap is my favourit framework of CSS. I used it for all my website projects.</p>
							</div>
						<div class="project-technology-content col-sm-3">
							<img src="reggiecril/resources/assets/Images/jQuery-Disable-Button - Disabling-and-Enabling-Buttons-with-jQuery.png" width="120" height="120" style="float: left;">
							<p><strong style="font-size: 24px;">M</strong>ost people like use jQuery to design website to make it dynamicily or animatedly and me too. I used jQuery in all of my website project.</p>
						</div>
						<div class="project-technology-content col-sm-3">
							<img src="reggiecril/resources/assets/Images/touchicon-180.png" width="120" height="120" style="float: left;">
							<p><strong style="font-size: 24px;" style="font-size: 30px;">I</strong> have one project about Android. In that project, I used Java as programming language. I learned Android for few months ago. Also, I do have some knowledge about Kotlin as programming language for Android.</p>
						</div>
						<div class="project-technology-content">
							<img src="reggiecril/resources/assets/Images/1200px-MySQL.svg.png" width="150" height="120" style="float: left;">
							<p><strong style="font-size: 24px;">M</strong>ySQL is used with PHP at usual. My E-commerce website project used MySQL to store data.</p>
						</div>
					</div>
			<h1>About Me</h1>
			<div>
				<p style="font-size: 26px;">A highly experienced and creative <strong>web developer</strong> with an experience in a variety of exciting projects.<a href="<?php echo e(url('/project')); ?>">See More...</a></p>

				<p style="font-size: 26px;">A level head and rational approach to problem solving combined with a passion for innovative and fresh ideas has led to a portfolio of impressive website solutions. </p>

				<p style="font-size: 26px;">Technically competent and industry aware means that each project is undertaken with the most up-to-date and relevant programming foundations available. A strong communicator with the ability to convey ideas clearly with an emphasis on client satisfaction.</p>
			</div>
		</div>
</body>
<footer>
	<div class="footer-background"></div>
	<div class="footer-title">
			<h1>GET IN TOUCH</h1>
			<p>You may want to connect me.</p>
		</br>
			<a href="javascript:void();"  data-toggle="modal" data-target="#contact" style="font-size: 30px;">Contact Me</a></p>
	</div>
	<div class="footer-content">
		<div class="footer-icon">
			<h1>Reggiecril</h1>
			<p>Xie Yuncheng</p>
		</div>
		
				<div class="footer-github">
					<h2 style="font-size: 35px;">Activity:</h2>
					<p>See more activity and project about Xie Yuncheng</p>
					<a href="https://github.com/Reggiecril" class="btn btn-primary btn-lg" ><img src="reggiecril/resources/assets/Images/bfa_brands-github-square_flat-circle-white-on-blue_512x512.png" width="35" height="35"> Enter to Xie's Github</a>
				</div>
				<div class="footer-media">
					<div style="display: inline-block;margin-right: 20px;color:  #dd4b39"><a href="" style="color: #dd4b39"><i class="fab fa-google-plus"></i></a></div>
					<div style="display: inline-block;margin-right: 20px;color: #D52341"><a href="" style="color: #D52341"><i class="fab fa-instagram"></i></a></div>
					<div style="display: inline-block;margin-right: 20px;color:#3b5998;"><a href="" style="color: #3b5998;"><i class="fab fa-facebook-square"></i></a></div>
					<div style="display: inline-block;margin-right: 20px;"><a href="" style="color: #333;"><i class="fab fa-github"></i></a></div>
					<div style="display: inline-block;margin-right: 20px;color: #205081"><a href="" style="color: #205081"><i class="fab fa-bitbucket"></i></a></div>
				</div>
			
	</div>
	<div style="text-align: center;padding-bottom: 20px;">©2018 Xie Yuncheng. All rights reserved.</div>
</footer>
<div class="modal fade" id="contact" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title" id="exampleModalLabel" data-toggle="modal" data-target="#contact">Contact Me</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="name" class="form-control-label">Name:</label>
            <input type="text" class="form-control" id="name">
          </div>
           <div class="form-group">
            <label for="email" class="form-control-label">Email:</label>
            <input type="email" class="form-control" id="email">
          </div>
          <div class="form-group">
            <label for="message-text" class="form-control-label">Message:</label>
            <textarea class="form-control" id="message"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-secondary">Send message</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$(document).ready(function(){
	$('.flexslider').flexslider({
		directionNav: true,
		pauseOnAction: true
	});
});
$(function() {
	$('.nav ul li').on('click', function() {
		$(this).addClass('nav_active');
		$(this).siblings().removeClass('nav_active');
	}).on('mouseenter', function() {
		$(this).children().children('span').addClass('nav_animate');
		$(this).siblings().children().children('span').removeClass('nav_animate');

	})
	$('.nav').on('mouseleave', function() {
		$('.nav_table_cell_link').children('span').removeClass('nav_animate');
	})
})
</script>
</html>