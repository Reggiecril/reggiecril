@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Create a new product </div>
                <div class="panel-body">

                    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <strong>create failed</strong> enter right charester<br><br>
                            {!! implode('<br>', $errors->all()) !!}
                        </div>
                    @endif

                    <form action="{{ url('/product') }}" method="POST">
                        {!! csrf_field() !!}
                        <input type="text" name="name" class="form-control" placeholder="Name" value="">
                        <br>
                        <input type="text" name="type" class="form-control" placeholder="Type" value="">
                        <br>
                        <input type="text" name="price" class="form-control" placeholder="Price" value="">
                        <br>
                        <input type="text" name="image" class="form-control" placeholder="Image" value="">
                        <br>
                        <button class="btn btn-lg btn-info">Add</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection