<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="Xie Yuncheng">
	<title>Reggie's Portfolio</title>
	<link href="https://fonts.googleapis.com/css?family=Playball" rel="stylesheet">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="reggiecril/resources/assets/style.css">
	<script type="text/javascript" src="reggiecril/resources/assets/js/jquery-3.3.1.js"></script>
	 <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="reggiecril/resources/assets/js/jquery.flexslider-min.js"></script>
</head>
<body>
	<div class="header">
		<div class="header-background"></div>
		<div class="header-content">
				<div class="header-topbar">
					<div class="header-icon">
						<h1>Reggiecril</h1>
					</div>
					<div style="display: inline-block;margin: 40px"></div>
					<div class="header-navigation ">
						<div class="nav">
							<ul class="nav_table">
								<li class="nav_table_cell">
									<a class="nav_table_cell_link"  href="{{ url('/') }}">
										<span></span> Home
									</a>
								</li>
								<li class="nav_table_cell">
									<a class="nav_table_cell_link" href="https://github.com/Reggiecril">
										<span></span> Github
									</a>
								</li>
								<li class="nav_table_cell">
									<a class="nav_table_cell_link" href="{{ url('/project') }}">
										<span></span> Projects
									</a>
								</li>
								<li class="nav_table_cell">
									<a class="nav_table_cell_link" href="https://www.linkedin.com/in/xie-yuncheng-038a16158">
										<span></span> Linkedin
									</a>
								</li>
								<li class="nav_table_cell">
									<a class="nav_table_cell_link" data-toggle="modal" data-target="#contact">
										<span></span> Contact Me
									</a>
								</li>
							</ul>
						</div>
					</div>
					<div class="header-search">
						<form action="" class="search-form">
			                <div class="form-group has-feedback">
			            		<label for="search" class="sr-only">Search</label>
			            		<input type="text" class="form-control" name="search" id="search" placeholder=" search">
			              		<span class="glyphicon glyphicon-search form-control-feedback"></span>
			            	</div>
			            </form>
					</div>
				</div>
				<div style="width: 1400px;margin:0 auto;margin-top: 200px;">
					<div class="project-technology-first">
						<div class="project-technology-content col-lg-3">
								<img src="reggiecril/resources/assets/Images/200px-HTML5_logo_and_wordmark.svg.png" width="100" height="100" style="float: left;">
							<p><strong style="font-size: 24px;">T</strong>his is basic technology in webiste development. I have a good understanding in HTML, using DIV,Tag skillful.</p>
						</div>
						<div class="project-technology-content col-sm-3">
							
							<img src="reggiecril/resources/assets/Images/2000px-PHP-logo.svg.png" width="150" height="120" style="float: left;">
							<p><strong style="font-size: 24px;">T</strong>his the first language which I touched and learned. Most of my project is developed on it, its simple and dynamic are the best thing which I like. I have a deep study on PHP. OO Programming is used and I used Laravel for my PHP framework.</p>
						</div>
						<div class="project-technology-content">
							
							<img src="reggiecril/resources/assets/Images/Java.png" width="100" height="140" style="float: left;">
						
							<p><strong style="font-size: 24px;">I</strong> learned Java for one years ago and have a understanding in Java SE. There are few projects available. I like this language and i am very interesting in Java EE,so Java EE prepared that is my next stage.</p>
						</div>
					</div>
					<div class="project-technology-second">
							<div class="project-technology-content col-sm-3">
								<img src="reggiecril/resources/assets/Images/css-3.svg" width="120" height="120" style="float: left;">
								<p><strong style="font-size: 24px;">T</strong>his is necessary tecchnology in website design. I study it thre years ago, same as HTML. Bootstrap is my favourit framework of CSS. I used it for all my website projects.</p>
							</div>
						<div class="project-technology-content col-sm-3">
							<img src="reggiecril/resources/assets/Images/jQuery-Disable-Button - Disabling-and-Enabling-Buttons-with-jQuery.png" width="120" height="120" style="float: left;">
							<p><strong style="font-size: 24px;">M</strong>ost people like use jQuery to design website to make it dynamicily or animatedly and me too. I used jQuery in all of my website project.</p>
						</div>
						<div class="project-technology-content col-sm-3">
							<img src="reggiecril/resources/assets/Images/touchicon-180.png" width="120" height="120" style="float: left;">
							<p><strong style="font-size: 24px;" style="font-size: 30px;">I</strong> have one project about Android. In that project, I used Java as programming language. I learned Android for few months ago. Also, I do have some knowledge about Kotlin as programming language for Android.</p>
						</div>
						<div class="project-technology-content">
							<img src="reggiecril/resources/assets/Images/1200px-MySQL.svg.png" width="150" height="120" style="float: left;">
							<p><strong style="font-size: 24px;">M</strong>ySQL is used with PHP at usual. My E-commerce website project used MySQL to store data.</p>
						</div>
					</div>
				</div>
		
		</div>
	</div>
	<div class="project-content">
		<h2>My Project</h2>
			<div class="project-content-column">
				<div class="project-content-column-image">
					<div class="imagechange-3d image-hover1 hover">
			                <div class="imagechange-3d-inner">
			                    <div class="imgchange-1">
			                        <h1 style="position: absolute;top:25%;left:20%;text-align: center;font-size: 30px;font-family: 'Playball', cursive;color:#D52341;">CloudaPing</h1>
			                    </div>
			                    <div class="imgchange-2">
			                        <a href="cloudaping.com"><img src="reggiecril/resources/assets/Images/Screen-Shot-2014-01-02-at-4.27.12-AM.png" width="250px" height="140px"></a>
			                    </div>
			                </div>
		                </div>
				</div>
				<div class="project-content-column-text">
					<p style="float: right;padding:10px">Duration:9 months</p>
					<h1 style="font-family: 'Playball', cursive;color:#D52341;padding-bottom: 10px;">CloudaPing</h1>
					<p>This project is about E-Commerce and has two parts, there are PHP website and Android App. It cost 9 months. Website uses MySQL to connect database, Android App connects website by JSON. This website have basic stuff of E-Commerence include trader add product, but Android App has no trader section.</p>
					<div class="project-content-column-text-technology">
						<a href="javascript:void()">PHP</a><a href="javascript:void()"> , </a><a href="javascript:void()">JavaScript</a><a href="javascript:void()"> , </a><a href="javascript:void()">MySQL</a><a href="javascript:void()"> , </a><a href="javascript:void()">XAMPP</a><a href="javascript:void()"> , </a><a href="javascript:void()">Android</a><a href="javascript:void()"> , </a><a href="javascript:void()">Java</a>
					</div>
				</div>
			</div>
			<div class="project-content-column">
				<div class="project-content-column-image">
					<div class="imagechange-3d image-hover1 hover">
			                <div class="imagechange-3d-inner">
			                    <div class="imgchange-1">
			                        <h1 style="position:absolute;text-align: center;top:25%;bottom:0;left:0;right:0;font-family: 'Playball', cursive;color:#128954;">Whsii</h1>
			                    </div>
			                    <div class="imgchange-2">
			                        <a href="http://reggiecril.com/web_dev.php"><img src="reggiecril/resources/assets/Images/_RHT5688_banner.jpg" width="250px" height="140px"></a>
			                    </div>
			                </div>
		                </div>
				</div>
				<div class="project-content-column-text">
					<p style="float: right;padding:10px">Duration:6 months</p>
					<h1 style="font-family: 'Playball', cursive;color:#128954;padding-bottom: 10px;">Whsii</h1>
					<p>This is a E-Commerce website. It uses OO Programming and Laravel framework to develop.It cost 6 months.</p>
					<div class="project-content-column-text-technology">
						<a href="javascript:void()">PHP</a><a href="javascript:void()"> , </a><a href="javascript:void()">JavaScript</a><a href="javascript:void()"> , </a><a href="javascript:void()">MySQL</a><a href="javascript:void()"> , </a><a href="javascript:void()">XAMPP</a><a href="javascript:void()"> , </a></a><a href="javascript:void()">JSON</a>
					</div>
				</div>
			</div>
			<div class="project-content-column">
				<div class="project-content-column-image">
					<div class="imagechange-3d image-hover1 hover">
			                <div class="imagechange-3d-inner">
			                    <div class="imgchange-1">
			                        <h1 style="position: absolute;top:25%;left:20%;text-align: center;font-size: 30px;font-family: 'Playball', cursive;color:#333;">Text Painter</h1>
			                    </div>
			                    <div class="imgchange-2">
			                        <a href="https://github.com/Reggiecril/TextPainter"><img src="reggiecril/resources/assets/Images/380px-Olympic_flag.svg.png" width="250px" height="140px"></a>
			                    </div>
			                </div>
		                </div>
				</div>
				<div class="project-content-column-text">
					<p style="float: right;padding:10px">Duration:4 months</p>
					<h1 style="font-family: 'Playball', cursive;color:#333;padding-bottom: 10px;">Text Painter</h1>
					<p>Different with normal paint board application. This application is point by entering coordinate. It is develop by Java,a small and simple application. It cost 4 months.</p>
					<div class="project-content-column-text-technology">
						<a href="javascript:void()">Java</a>
					</div>
				</div>
			</div>
			<div class="project-content-column">
				<div class="project-content-column-image">
					<div class="imagechange-3d image-hover1 hover">
			                <div class="imagechange-3d-inner">
			                    <div class="imgchange-1">
			                        <h1 style="position: absolute;top:25%;left:30%;text-align: center;font-size: 30px;color:#333;">Bronte</h1>
			                    </div>
			                    <div class="imgchange-2">
			                        <a href="https://github.com/Reggiecril/Bronte"><img src="reggiecril/resources/assets/Images/market.jpg" width="250px" height="140px"></a>
			                    </div>
			                </div>
		                </div>
				</div>
				<div class="project-content-column-text">
					<p style="float: right;padding:10px">Duration:6 months</p>
					<h1 style="color:#D52341;padding-bottom: 10px;">Bronte</h1>
					<p>THis is a team work project. Bronte is a E-Commerce website, I am working in website development. </p>
					<div class="project-content-column-text-technology">
						<a href="javascript:void()">PHP</a><a href="javascript:void()"> , </a><a href="javascript:void()">JavaScript</a><a href="javascript:void()"> , </a><a href="javascript:void()">MySQL</a><a href="javascript:void()"> , </a><a href="javascript:void()">XAMPP</a>
					</div>
				</div>
			</div>
			<div class="project-content-column">
				<div class="project-content-column-image">
					<div class="imagechange-3d image-hover1 hover">
			                <div class="imagechange-3d-inner">
			                    <div class="imgchange-1">
			                        <h1 style="position: absolute;top:25%;left:22%;text-align: center;font-size: 30px;color:rgb(192,64,0);">Bug Tracker</h1>
			                    </div>
			                    <div class="imgchange-2">
			                        <a href="https://github.com/Reggiecril/reggie-2017-ASDA-2"><img src="reggiecril/resources/assets/Images/feedback-assistant-mac-icon-100596716-large.png" width="250px" height="140px"></a>
			                    </div>
			                </div>
		                </div>
				</div>
				<div class="project-content-column-text">
					<p style="float: right;padding:10px">Duration:4 months</p>
					<h1 style="color:rgb(192,64,0);padding-bottom: 10px;">Bug Tracker</h1>
					<p>This is a C# project. This project is using for find bug of application and fix them. It based on database, to transfer bug information from tester to developer.It cost 4 months.</p>
					<div class="project-content-column-text-technology">
						<a href="javascript:void()">Java</a><a href="javascript:void()"> , </a><a href="javascript:void()">C#</a>
					</div>
				</div>
			</div>
			<div class="project-content-column">
				<div class="project-content-column-image">
					<div class="imagechange-3d image-hover1 hover">
			                <div class="imagechange-3d-inner">
			                    <div class="imgchange-1">
			                        <h1 style="position: absolute;top:25%;left:30%;text-align: center;font-size: 30px;color:#333;">Fractal</h1>
			                    </div>
			                    <div class="imgchange-2">
			                        <a href="https://github.com/Reggiecril/reggie-2017-ASDA-1"><img src="reggiecril/resources/assets/Images/Demm_2000_Mandelbrot_set.jpg" width="250px" height="140px"></a>
			                    </div>
			                </div>
		                </div>
				</div>
				<div class="project-content-column-text">
					<p style="float: right;padding:10px">Duration:3 months</p>
					<h1 style="color:#333;padding-bottom: 10px;">Fractal</h1>
					<p>This project is that convert from Java to C#. It based on mandelbrot and support to zoom unlimited. It cost 3 months.</p>
					<div class="project-content-column-text-technology">
						<a href="javascript:void()">Java</a><a href="javascript:void()"> , </a><a href="javascript:void()">C#</a>
					</div>
				</div>
			</div>
			<div class="project-content-column">
				<div class="project-content-column-image">
					<div class="imagechange-3d image-hover1 hover">
			                <div class="imagechange-3d-inner">
			                    <div class="imgchange-1">
			                        <h1 style="position: absolute;top:25%;left:35%;text-align: center;font-size: 30px;color:#D52341;">Polar</h1>
			                    </div>
			                    <div class="imgchange-2">
			                        <a href="https://github.com/Reggiecril/ASDB"><img src="reggiecril/resources/assets/Images/Polar.png" width="250px" height="140px"></a>
			                    </div>
			                </div>
		                </div>
				</div>
				<div class="project-content-column-text">
					<p style="float: right;padding:10px">Duration:Developing</p>
					<h1 style="color:#D52341;padding-bottom: 10px;">Polar</h1>
					<p>This is an application which load exercise data form file, and display it with text and chart. Helping user to understanding how they exercise.</p>
					<div class="project-content-column-text-technology">
						<a href="javascript:void()">Java</a>
					</div>
				</div>
			</div>
			<div class="project-content-column">
				<div class="project-content-column-image">
					<div class="imagechange-3d image-hover1 hover">
			                <div class="imagechange-3d-inner">
			                    <div class="imgchange-1">
			                        <h1 style="position: absolute;top:25%;left:30%;text-align: center;font-size: 30px;font-family: 'Playball', cursive;color:#D52341;">Whisky</h1>
			                    </div>
			                    <div class="imgchange-2">
			                        <a href="https://github.com/Reggiecril/Whisky"><img src="reggiecril/resources/assets/Images/best_whiskies_2018_-_whiskey_glass.jpg" width="250px" height="140px"></a>
			                    </div>
			                </div>
		                </div>
				</div>
				<div class="project-content-column-text">
					<p style="float: right;padding:10px">Duration:3 months</p>
					<h1 style="color:#D52341;padding-bottom: 10px;">Whisky</h1>
					<p>This is a E-Commerence website for selling whisky. It has all CRUD from database and it is one page website.</p>
					<div class="project-content-column-text-technology">
						<a href="javascript:void()">PHP</a><a href="javascript:void()"> , </a><a href="javascript:void()">JavaScript</a><a href="javascript:void()"> , </a><a href="javascript:void()">MySQL</a><a href="javascript:void()"> , </a><a href="javascript:void()">XAMPP</a>
					</div>
				</div>
			</div>
	</div>
</body>
<footer>
	<div class="footer-background"></div>
	<div class="footer-title">
			<h1>GET IN TOUCH</h1>
			<p>You may want to connect me.</p>
		</br>
			<a href="javascript:void();"  data-toggle="modal" data-target="#contact" style="font-size: 30px;">Contact Me</a></p>
	</div>
	<div class="footer-content">
		<div class="footer-icon">
			<h1>Reggiecril</h1>
			<p>Xie Yuncheng</p>
		</div>
		
				<div class="footer-github">
					<h2 style="font-size: 35px;">Activity:</h2>
					<p>See more activity and project about Xie Yuncheng</p>
					<a href="https://github.com/Reggiecril" class="btn btn-primary btn-lg" ><img src="reggiecril/resources/assets/Images/bfa_brands-github-square_flat-circle-white-on-blue_512x512.png" width="35" height="35"> Enter to Xie's Github</a>
				</div>
				<div class="footer-media">
					<div style="display: inline-block;margin-right: 20px;color:  #dd4b39"><a href="" style="color: #dd4b39"><i class="fab fa-google-plus"></i></a></div>
					<div style="display: inline-block;margin-right: 20px;color: #D52341"><a href="" style="color: #D52341"><i class="fab fa-instagram"></i></a></div>
					<div style="display: inline-block;margin-right: 20px;color:#3b5998;"><a href="" style="color: #3b5998;"><i class="fab fa-facebook-square"></i></a></div>
					<div style="display: inline-block;margin-right: 20px;"><a href="" style="color: #333;"><i class="fab fa-github"></i></a></div>
					<div style="display: inline-block;margin-right: 20px;color: #205081"><a href="" style="color: #205081"><i class="fab fa-bitbucket"></i></a></div>
				</div>
			
	</div>
	<div style="text-align: center;padding-bottom: 20px;">©2018 Xie Yuncheng. All rights reserved.</div>
</footer>
<div class="modal fade" id="contact" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title" id="exampleModalLabel" data-toggle="modal" data-target="#contact">Contact Me</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="name" class="form-control-label">Name:</label>
            <input type="text" class="form-control" id="name">
          </div>
           <div class="form-group">
            <label for="email" class="form-control-label">Email:</label>
            <input type="email" class="form-control" id="email">
          </div>
          <div class="form-group">
            <label for="message-text" class="form-control-label">Message:</label>
            <textarea class="form-control" id="message"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-secondary">Send message</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$(function() {
	$('.nav ul li').on('click', function() {
		$(this).addClass('nav_active');
		$(this).siblings().removeClass('nav_active');
	}).on('mouseenter', function() {
		$(this).children().children('span').addClass('nav_animate');
		$(this).siblings().children().children('span').removeClass('nav_animate');

	})
	$('.nav').on('mouseleave', function() {
		$('.nav_table_cell_link').children('span').removeClass('nav_animate');
	})
})
</script>
</html>